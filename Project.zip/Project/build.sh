#!/bin/bash

# Detect OS
OS="$(uname -s)"
case "$OS" in
    Linux*)  PLATFORM="linux";;
    MINGW*|CYGWIN*|MSYS*) PLATFORM="windows";;
    *) echo "Unsupported OS: $OS"; exit 1;;
esac

# Compiler and build settings
CC="aarch64-none-linux-gnu-gcc"
CFLAGS="-Wall -O2"        # Customize as needed
SRC_DIR="src"             # Source files directory
OUT_DIR="build"           # Output directory
TARGET="output_binary"    # Final binary name

# Create build directory if not exists
mkdir -p "$OUT_DIR"

# Compile and link
echo "Building on $PLATFORM..."
$CC $CFLAGS "$SRC_DIR"/*.c -o "$OUT_DIR/$TARGET"

# Check build result
if [ $? -eq 0 ]; then
    echo "Build succeeded! Output: $OUT_DIR/$TARGET"
else
    echo "Build failed!"
    exit 1
fi
