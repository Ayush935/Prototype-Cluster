#include <stdio.h>
int main() {
   // printf() displays the string inside quotation
   printf("Hello, World!");
   return 0;
}

// wget http://dl-cdn.alpinelinux.org/alpine/v3.16/releases/aarch64/alpine-minirootfs-3.16.2-aarch64.tar.gz
// mkdir /home/kpit/arm-rootfs
// tar -xvzf alpine-minirootfs-3.16.2-aarch64.tar.gz -C /home/kpit/arm-rootfs

// sudo apt update
// sudo apt install qemu-user-static libc6:arm64

// sudo apt update
// apt-cache search libc6
// sudo dpkg --add-architecture arm64
// sudo apt update
