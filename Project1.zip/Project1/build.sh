#!/bin/bash

# Check if the operating system is Windows or Linux
OS=$(uname -s)

# Set the compiler to clang
COMPILER="clang++"

# Set the output file name
OUTPUT="program"

# Set the source files (adjust according to your project)
SRC_FILES="main.cpp"

# Compilation flags (add more as necessary)
FLAGS="-std=c++17 -O2 -Wall"

# Add platform-specific flags
if [[ "$OS" == "Linux" ]]; then
    # Linux specific flags (if any)
    FLAGS="$FLAGS -pthread"
    echo "Detected Linux. Using Clang with flags: $FLAGS"
elif [[ "$OS" == "MINGW64_NT"* || "$OS" == "CYGWIN_NT"* ]]; then
    # Windows-specific flags for Clang (Mingw or Cygwin)
    FLAGS="$FLAGS -mwindows"
    echo "Detected Windows. Using Clang with flags: $FLAGS"
else
    echo "Unsupported OS"
    exit 1
fi

# Compile the program using clang
echo "Compiling with $COMPILER..."
$COMPILER $SRC_FILES $FLAGS -o $OUTPUT

# Check if compilation was successful
if [ $? -eq 0 ]; then
    echo "Build successful! Executable created: $OUTPUT"
else
    echo "Build failed."
    exit 1
fi
